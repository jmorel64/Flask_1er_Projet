DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
    `pseudo` varchar(255) PRIMARY KEY NOT NULL,
    `prenom` varchar(255),
    `nom` varchar(255),
    `sexe` varchar(255)
);

DROP TABLE IF EXISTS `recherches`;
CREATE TABLE `recherches` (
    `id` INT PRIMARY KEY NOT NULL AUTO_INCREMENT,
    `symbol` TEXT NOT NULL,
    `company_name` TEXT NOT NULL,
    `date_recherche` DATE NOT NULL
);