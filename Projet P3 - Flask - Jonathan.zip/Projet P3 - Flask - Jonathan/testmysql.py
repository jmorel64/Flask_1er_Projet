# Avant de lancer l'application :
    # Creer la base de donner des tables user et recherches dans Dbeaver avec le fichier SQL BD_SQL
    # Dans le code mettre son user et passeword pour connecter la base de donnée
    # Dans le code mettre sa clé d'API Alpha Vantage dans la def get_stock_data et la def generate_graph



from flask import Flask, render_template, request, redirect, jsonify
import mysql.connector
import re
import requests
import datetime
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import BytesIO
import base64
#import os
from PIL import Image
import joblib


app = Flask(__name__)



# Configuration de la connexion à la base de données MySQL
db = mysql.connector.connect(
    host='localhost', 
    user='xxxx', # à modifier
    password='xxxx', # à modifier
    database='user'
)

cursor = db.cursor()


@app.route('/')
def rediriger_vers_formulaire():
    return redirect('/test-formulaire')

# Page /test-formulaire pour l'affichage du formulaire
@app.route('/test-formulaire', methods=['GET', 'POST'])
def formulaire():
    message_success = None
    message_error = None
    if request.method == 'POST':
        # Récupérer les données du formulaire
        pseudo = request.form['pseudo']
        prenom = request.form['prenom']
        nom = request.form['nom']
        sexe = request.form['sexe']

        # Vérifier si tous les champs sont remplis
        if pseudo and prenom and nom and sexe:
            # Vérifier que les champs nom et prénom ne contiennent que des lettres et des caractères spéciaux
            if not re.match("^[A-Za-zÀ-ÿ'\- ]+$", prenom) or not re.match("^[A-Za-zÀ-ÿ'\- ]+$", nom):
                message_error = "Les champs nom et prénom ne peuvent pas contenir de chiffres."
            else:
                # Mettre les informations en majuscules
                pseudo = pseudo.upper()
                prenom = prenom.upper()
                nom = nom.upper()
                # Insérer les données dans la base de données
                try:
                    cursor.execute(
                        "INSERT INTO users (pseudo, prenom, nom, sexe) VALUES (%s, %s, %s, %s)",
                        (pseudo, prenom, nom, sexe)
                    )
                    db.commit()
                    message_success = "Utilisateur enregistré avec succès !"
                except mysql.connector.Error as err:
                    db.rollback()
                    message_error = f"Le pseudo existe déjà veuillez en renseigner un nouveau"
        else:
            message_error = "Veuillez remplir tous les champs du formulaire."

    return render_template('formulaire.html', message_success=message_success, message_error=message_error)


@app.route('/utilisateurs-inscrits')
def liste_utilisateurs():
    try:
        cursor.execute("SELECT pseudo, prenom, nom, sexe FROM users")
        utilisateurs = cursor.fetchall()
        # utilisateurs contient maintenant toutes les lignes récupérées de la base de données
    except mysql.connector.Error as err:
        print(f"Erreur lors de la récupération des utilisateurs : {err}")
        utilisateurs = []
    return render_template('utilisateurs.html', utilisateurs=utilisateurs)


@app.route('/get-stock-data', methods=['GET', 'POST'])
def get_stock_data():
    stock_data = None
    message = None
    if request.method == 'POST':
        company_symbol = request.form['companySymbol']
        api_key = 'xxxx'  # Remplacez par votre clé d'API Alpha Vantage

        # Effectuer la requête vers l'API Alpha Vantage
        url = f'https://www.alphavantage.co/query?function=OVERVIEW&symbol={company_symbol}&apikey={api_key}'
        response = requests.get(url)

        if response.status_code == 200:
            stock_data = response.json()
            if not stock_data:
                message = "L'entreprise ne fait pas partie de la base de données ou est mal renseignée."

            # pour la bd sql des recherches API    
            # Enregistrement des données de la recherche dans la base de données
        try:
            cursor.execute(
                "INSERT INTO recherches (symbol, company_name, date_recherche) VALUES (%s, %s, %s)",
                (company_symbol, stock_data.get('Name', ''), datetime.date.today())
            )
            db.commit()
        except mysql.connector.Error as err:
            db.rollback()
                

    return render_template('news.html', stock_data=stock_data, message=message)


@app.route('/search-history')
def liste_recherche():
    try:
        cursor.execute("SELECT * FROM recherches ORDER BY date_recherche DESC")
        recherches = cursor.fetchall()
    except mysql.connector.Error as err:
        print(f"Erreur lors de la récupération de la recherche : {err}")
        recherches = []
    return render_template('recherches.html', recherches=recherches)


@app.route('/stat', methods=['GET', 'POST'])
def stat():
    stats = None
    error = None

    if request.method == 'POST':
        if 'file' not in request.files:
            error = 'Aucun fichier chargé'
        else:
            file = request.files['file']

            if file.filename == '':
                error = 'Aucun fichier sélectionné'
            else:
                try:
                    if file.filename.endswith('.csv'):
                        df = pd.read_csv(file)
                    elif file.filename.endswith(('.xls', '.xlsx')):
                        df = pd.read_excel(file)
                    else:
                        error = 'Format de fichier non pris en charge'

                    if error is None:
                        stats = df.describe().to_html(classes='table table-striped')

                except Exception as e:
                    error = f'Erreur lors de la lecture du fichier : {str(e)}'

    return render_template('statistique.html', stats=stats, error=error)


def generate_graph(stock_symbol):
    API_KEY = 'xxxx' # Remplacez par votre clé d'API Alpha Vantage
    api_url = f'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY&symbol={stock_symbol}&apikey={API_KEY}'
    
    try:
        response = requests.get(api_url)
        data = response.json()

        if 'Time Series (Daily)' in data:
            dates = list(data['Time Series (Daily)'].keys())[:30]  # 30 derniers jours
            prices = [float(data['Time Series (Daily)'][date]['4. close']) for date in dates]

            x = np.arange(len(dates))

            plt.figure(figsize=(8, 4))
            plt.plot(x, prices, label='Prix de l\'action')
            plt.xlabel('Jours')
            plt.ylabel('Prix')
            plt.title(f'Graphique du prix de l\'action ({stock_symbol})')
            plt.legend()
            
            # Convertir le graphique en base64 pour l'intégrer dans la page HTML
            buffer = BytesIO()
            plt.savefig(buffer, format='png')
            buffer.seek(0)
            image_base64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
            plt.close()

            return image_base64

        else:
            return None

    except Exception as e:
        print(f"Une erreur s'est produite : {str(e)}")
        return None

@app.route('/graph', methods=['GET', 'POST'])
def graph():
    stock_symbol = ''
    image_base64 = ''

    if request.method == 'POST':
        stock_symbol = request.form['stock_symbol']
        image_base64 = generate_graph(stock_symbol)

    return render_template('bourse.html', stock_symbol=stock_symbol, image_base64=image_base64)




# Charger le modèle
model = joblib.load('mnist_logistic_regression_model.pkl')

# Charger le scaler
scaler = joblib.load('mnist_standard_scaler.pkl')



@app.route('/predict', methods=['GET', 'POST'])
def predict():
    if request.method == 'POST':
        if 'file' not in request.files:
            return "Aucun fichier n'a été téléchargé."

        file = request.files['file']
        if file.filename == '':
            return "Choisir un autre fichier sélectionné."

        # Prétraitement de l'image
        img = Image.open(file)
        img_array = np.array(img)
        img_resized = np.resize(img_array, (28, 28))
        img_flattened = img_resized.flatten().reshape(1, -1)

        # Normalisation de l'image avec le scaler
        img_normalized = scaler.transform(img_flattened)

        # Prédiction avec le modèle
        prediction = model.predict(img_normalized)
        
        message = f"La prédiction du modèle est : {prediction[0]}"
        return render_template('chiffre.html', message=message)
    else:
        message = ""
        return render_template('chiffre.html', message=message)


def preprocess_image(img):
    # Prétraiter l'image pour la prédiction du modèle
    img = img.convert('L')  # Convertir en niveau de gris
    img = img.resize((28, 28))  # Redimensionner à la taille attendue par le modèle
    img_array = np.array(img)  # Convertir en tableau numpy
    img_array = img_array.flatten()  # Aplatir le tableau
    img_array = img_array / 255.0  # Normaliser les valeurs des pixels entre 0 et 1
    return img_array


@app.route('/dessin', methods=['GET', 'POST'])
def dessin():
    if request.method == 'POST':
        img_data = request.form.get('imgData')
        if img_data:
            # Traitement des données de l'image
            parsed_data = preprocess_image_from_base64(img_data)

            # Exécuter la logique de prédiction avec parsed_data
            prediction = model.predict([parsed_data])[0]
            return str(prediction)
        else:
            return "Aucune donnée d'image reçue."
    else:
        message = ""
    return render_template('dessin.html', message=message)

def preprocess_image_from_base64(base64_string):
    # Convertir l'image base64 en tableau numpy
    img_data = base64.b64decode(base64_string)
    img = Image.open(BytesIO(img_data))
    img_array = preprocess_image(img)
    return img_array



if __name__ == '__main__':
    app.run(debug=True, use_reloader=False)


