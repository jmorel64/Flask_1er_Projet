from sklearn.linear_model import LogisticRegression
from sklearn.datasets import fetch_openml
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import joblib

def train_model():
    # Charger le dataset MNIST
    mnist = fetch_openml('mnist_784')

    # Mise en forme des données
    X = mnist.data.astype('float32')
    y = mnist.target.astype('int64')

    # Normalisation des valeurs des pixels pour être comprises entre 0 et 1
    X /= 255.0

    # Diviser les données en ensembles d'entraînement et de test
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Créer et entraîner le modèle de régression logistique
    model = LogisticRegression(solver='lbfgs', max_iter=1000, multi_class='auto')
    model.fit(X_train, y_train)

    # Évaluer le modèle
    accuracy = model.score(X_test, y_test)
    print(f'Accuracy: {accuracy}')

    # Sauvegarder le modèle
    joblib.dump(model, 'mnist_logistic_regression_model.pkl')

    # Sauvegarder le scaler
    scaler = StandardScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    joblib.dump(scaler, 'mnist_standard_scaler.pkl')

if __name__ == "__main__":
    train_model()